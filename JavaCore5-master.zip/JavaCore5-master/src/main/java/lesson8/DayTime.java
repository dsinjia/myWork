package lesson8;

public enum DayTime {
    NIGHT,
    DAY,
    MORNING,
    EVENING
}
