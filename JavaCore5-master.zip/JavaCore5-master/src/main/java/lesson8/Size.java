package lesson8;

public enum Size {
    S,
    XS,
    XXS,
    M,
    L,
    XL,
    XXL,
    XXXL,
    XXXS
}
