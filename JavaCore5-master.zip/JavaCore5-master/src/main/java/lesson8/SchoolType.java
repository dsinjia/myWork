package lesson8;

public enum SchoolType {
    PRIVATE,
    PUBLIC,
    CHARTER
}
