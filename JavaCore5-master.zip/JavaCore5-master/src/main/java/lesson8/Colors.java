package lesson8;

public enum Colors {
    RED,
    GREEN,
    BLUE,
    PINK,
    WHITE,
    BROWN,
    CYAN,
    MAGENTA,
    YELLOW,
    BLACK,
    ORANGE
}
