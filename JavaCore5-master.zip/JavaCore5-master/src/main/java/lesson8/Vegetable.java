package lesson8;

public enum Vegetable {
}
