package lesson8;

public enum Fruits {
    APPLE,
    PEACH,
    PLUM,
    AVOCADO,
    ORANGE,
    LEMON,
    PAPAYA,
    STAR_FRUIT
}
