package lesson13;

public enum Colors {
    RED,
    GREEN,
    PINK
}
