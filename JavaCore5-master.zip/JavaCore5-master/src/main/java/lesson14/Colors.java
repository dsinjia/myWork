package lesson14;

public enum Colors {
    GREEN,
    RED,
    ORANGE,
    YELLOW,
    BROWN,
    GREY,
    PINK
}
