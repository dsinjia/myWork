package lesson11;

public final class TabletPC extends PortableComputer{
}
