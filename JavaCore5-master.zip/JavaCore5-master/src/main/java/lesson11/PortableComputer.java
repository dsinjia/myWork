package lesson11;

public class PortableComputer extends Computer{
}
