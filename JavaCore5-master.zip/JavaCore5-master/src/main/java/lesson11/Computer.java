package lesson11;

public class Computer extends ElectricDevice{
}
