package lesson11;

public class ElectricDevice {
}
