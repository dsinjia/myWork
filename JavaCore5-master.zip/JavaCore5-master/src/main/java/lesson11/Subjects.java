package lesson11;

public enum Subjects {
    MATH,
    BIOLOGY,
    HISTORY,
    CS,
    BUSINESS,
    ECONOMIC
}
