package lesson10;

public enum Gender {
    MALE,
    FEMALE,
    XX
}
