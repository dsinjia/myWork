package lesson10;

public enum Subjects {
    MATH,
    HISTORY,
    BIOLOGY,
    CS,
    GRAPHIC_DESIGN
}
