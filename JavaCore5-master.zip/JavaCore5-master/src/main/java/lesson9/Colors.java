package lesson9;

public enum Colors {
    SILVER,
    BLACK,
    GOLD,
    WHITE
}
