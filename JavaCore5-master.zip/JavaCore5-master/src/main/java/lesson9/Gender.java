package lesson9;

public enum Gender {
    MALE,
    FEMALE,
    XX
}
