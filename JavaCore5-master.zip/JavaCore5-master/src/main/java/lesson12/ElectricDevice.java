package lesson12;

public abstract class ElectricDevice {
    protected String name;
    public abstract void hello();
}
