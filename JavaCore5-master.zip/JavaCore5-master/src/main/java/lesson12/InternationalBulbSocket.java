package lesson12;

public interface InternationalBulbSocket {
    void bulbStandard();
}
