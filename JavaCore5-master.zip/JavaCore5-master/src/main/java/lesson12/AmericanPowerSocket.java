package lesson12;

public interface AmericanPowerSocket {
    void contacts2();
    void mustBeFlat();
}
