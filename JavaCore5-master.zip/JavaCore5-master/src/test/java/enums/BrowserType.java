package enums;

public enum BrowserType {
    CHROME,
    FIREFOX,
    EDGE
}
